function setLanguage(lang) {
    fetch('lang.json')
      .then(res => res.json())
      .then(data => {
        document.querySelectorAll('[data-lang-id]').forEach(el => {
          const key = el.getAttribute('data-lang-id');
          if (data[lang] && data[lang][key]) {
            el.textContent = data[lang][key];
          }
        });
        localStorage.setItem('lang', lang);
      });
  }
  
  document.addEventListener('DOMContentLoaded', () => {
    const lang = localStorage.getItem('lang') || 'id';
    setLanguage(lang);
  });
  