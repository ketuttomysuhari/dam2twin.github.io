// Simpan titik yang diklik
let clickedPoints = [];
let pointEntities = [];
let distanceLabel;


handler.setInputAction(function (click) {
  const cartesian = viewer.scene.pickPosition(click.position);


  clickedPoints.push(cartesian);

  // Tambahkan titik sebagai entity
  const point = viewer.entities.add({
    position: cartesian,
    point: {
      pixelSize: 10,
      color: Cesium.Color.RED,
    },
    label: {
      text: cartesianToDMS(cartesian),
      font: "14px sans-serif",
      fillColor: Cesium.Color.YELLOW,
      style: Cesium.LabelStyle.FILL_AND_OUTLINE,
      verticalOrigin: Cesium.VerticalOrigin.TOP,
      pixelOffset: new Cesium.Cartesian2(0, -20),
    }
  });

  pointEntities.push(point);

  // Jika sudah dua titik, hitung jarak
  if (clickedPoints.length === 2) {
    const distance = Cesium.Cartesian3.distance(clickedPoints[0], clickedPoints[1]);

    // Tambahkan label jarak di tengah garis
    const midpoint = Cesium.Cartesian3.midpoint(clickedPoints[0], clickedPoints[1], new Cesium.Cartesian3());

    distanceLabel = viewer.entities.add({
      position: midpoint,
      label: {
        text: `Distance: ${distance.toFixed(2)} m`,
        font: "16px bold sans-serif",
        fillColor: Cesium.Color.CYAN,
        outlineColor: Cesium.Color.BLACK,
        outlineWidth: 2,
        style: Cesium.LabelStyle.FILL_AND_OUTLINE,
        verticalOrigin: Cesium.VerticalOrigin.BOTTOM,
      },
      polyline: {
        positions: clickedPoints,
        width: 2,
        material: Cesium.Color.ORANGE,
      }
    });

    // Reset agar bisa klik lagi
    clickedPoints = [];
    pointEntities = [];
  }

}, Cesium.ScreenSpaceEventType.LEFT_CLICK);

// Fungsi bantu: ubah koordinat ke derajat desimal
function cartesianToDMS(cartesian) {
  const cartographic = Cesium.Cartographic.fromCartesian(cartesian);
  const lon = Cesium.Math.toDegrees(cartographic.longitude).toFixed(6);
  const lat = Cesium.Math.toDegrees(cartographic.latitude).toFixed(6);
  const alt = cartographic.height.toFixed(2);
  return `Lon: ${lon}, Lat: ${lat}, Alt: ${alt} m`;
}
